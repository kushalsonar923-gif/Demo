# FAITHBETTING (demo prototype)

Frontend-only, free-to-play demo. Virtual coins only; no real money.

## Deploy on GitHub Pages
1. Create a repo and upload everything in this folder (keep `index.html` at the root and the `assets` folder).
2. Settings > Pages > Source: **Deploy from a branch**, branch `main`, folder `/ (root)`.
3. Open `https://<user>.github.io/<repo>/`.

## Adding images
Upload files into `assets/` using the names in `assets/README.md`. Reload; they appear automatically.

All paths are relative and routing uses `#hash`, so it works on project pages and custom domains.

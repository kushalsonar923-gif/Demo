# Assets

Drop images straight into this folder. No code or paths to edit: the site finds them by **filename** (lowercase, `.webp`, `.jpg`, `.jpeg`, `.png` or `.avif`).

| File name (without extension) | Used for |
|---|---|
| `logo` | Header logo (square) |
| `favicon` | Browser tab icon |
| `banner-1` to `banner-4` | Homepage slider backgrounds (wide, about 1600x600) |
| `fortune-tiger` | Fortune Tiger game card (portrait, about 600x730) |
| `fortune-mouse` | Fortune Mouse game card (portrait, about 600x730) |
| `fortune-ox` | Fortune Ox game card (portrait, about 600x730) |
| `ganesha-fortune` | Ganesha Fortune game card (portrait, about 600x730) |
| `dragon-fortune` | Dragon Fortune game card (portrait, about 600x730) |
| `lucky-fortune` | Lucky Fortune game card (portrait, about 600x730) |
| `golden-fish` | Golden Fish game card (portrait, about 600x730) |
| `wild-bandito` | Wild Bandito game card (portrait, about 600x730) |
| `jungle-adventure` | Jungle Adventure game card (portrait, about 600x730) |
| `candy-bonanza` | Candy Bonanza game card (portrait, about 600x730) |
| `treasure-hunt` | Treasure Hunt game card (portrait, about 600x730) |
| `lucky-dragon` | Lucky Dragon game card (portrait, about 600x730) |
| `fortune-rabbit` | Fortune Rabbit game card (portrait, about 600x730) |
| `magic-lamp` | Magic Lamp game card (portrait, about 600x730) |
| `golden-empire` | Golden Empire game card (portrait, about 600x730) |
| `plinko-drop` | Plinko Drop game card (portrait, about 600x730) |
| `crash-rocket` | Crash Rocket game card (portrait, about 600x730) |
| `mines-gems` | Mines Gems game card (portrait, about 600x730) |
| `baccarat-royale` | Baccarat Royale game card (portrait, about 600x730) |
| `blackjack-blitz` | Blackjack Blitz game card (portrait, about 600x730) |
| `royal-poker` | Royal Poker game card (portrait, about 600x730) |
| `shark-hunter` | Shark Hunter game card (portrait, about 600x730) |
| `ocean-king` | Ocean King game card (portrait, about 600x730) |
| `sky-pilot` | Sky Pilot game card (portrait, about 600x730) |
| `chicken-dash` | Chicken Dash game card (portrait, about 600x730) |
| `lucky-balls` | Lucky Balls game card (portrait, about 600x730) |
| `bingo-blast` | Bingo Blast game card (portrait, about 600x730) |
| `color-wheel` | Color Wheel game card (portrait, about 600x730) |

Tips: use WebP, keep each file under about 200 KB, and use lowercase names (GitHub Pages is case-sensitive). Use only artwork you own or have a licence for.
